//program to accept two integers and check whether they are equal or not
#include<iostream>
using namespace std;

int main(){
    int num1 , num2 ;

    cout<<"enter first intiger";
    cin>>num1;

    cout<<"enter second intiger";
    cin>>num2;

    if (num1 == num2){
        cout<<"the integers are equal"<<endl;
    } else {
        cout<<"the integers are not equal"<<endl; 
    }
    return 0;
}