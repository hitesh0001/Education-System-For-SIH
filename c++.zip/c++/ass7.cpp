//program to find sum and average of 3 numbers given from user
#include<iostream>
using namespace std;

int main(){
    float num1 , num2 , num3 ;
    float sum , average ;

    cout<<"enter first number";
    cin>>num1 ;

    cout<<"enter second number";
    cin>>num2 ;

    cout<<"enter third number";
    cin>>num3 ;

    sum = num1 + num2 + num3;

    average = sum / 3;

    cout<<"sum of the numbers"<<sum<<endl;
    cout<<"average of the numbers"<<average<<endl;
    
    return 0;
}