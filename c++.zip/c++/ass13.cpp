//program to find sum of digits of given number 
#include<iostream>
using namespace std;

int main(){
    int n ;
    cout<<"enter the number "<<endl;
    cin>> n ;
    int rem , sum =0;
    while(n!=0)
    {
        rem = n%10;
        sum = sum + rem ;
        n = n/10;
    }
    cout<<"sum is"<<sum<<endl;
    
    return 0;
}