//  program to initialize the data members of object using constructor
#include <iostream>
#include <string>
using namespace std;

class Person {
private:
    string name;
    int age;

public:
    // Constructor to initialize data members
    Person(string n, int a) {
        name = n;
        age = a;
    }

    // Function to display the person's details
    void display() {
        cout << "Name: " << name << endl;
        cout << "Age: " << age << endl;
    }
};

int main() {
    // Creating an object of Person and initializing it using the constructor
    Person person1("Alice", 30);
    
    // Displaying the details of person1
   person1.display();

    return 0;
}
