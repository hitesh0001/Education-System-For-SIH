#include<iostream>

using namespace std;
int main()
{
    /*loops in cpp :
    1 for 
    2 while 
    3 do while
    */

   /*syntax for FOR LOOP 
   for(initialization; condition; updation)
   {
    loop body(cpp code);
   }
   */

  for(int i =0; i<40; i++)
  {
    cout<<i<<endl;
  }
  return 0;  

}
