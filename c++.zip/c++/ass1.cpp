#include<iostream>
using namespace std;

int main(){
    cout<<"your name"<<endl;
    cout<<"your college name"<<endl;
    return 0;
}