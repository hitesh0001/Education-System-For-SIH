//program to generate table of a number entered by a user
#include<iostream>
using namespace std;

int main(){
    int number ;

    cout<<"enter a number";
    cin>>number;

    cout<<"multiplication table of "<< number <<":\n";
    for(int i = 1 ; i <= 10; ++i){
        cout << number << " * " << i <<" = " << number * i <<endl ;

    }

    return 0;
}