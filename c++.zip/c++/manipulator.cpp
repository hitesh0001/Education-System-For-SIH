#include<iostream>
#include<iomanip>

using namespace std ;

int main(){
    int a = 1 , b=2 ,c=3 , d=4 , e=5, f=6, g=7, h=8 ,i=9 ;
    cout<<"the value of a is:"<<setw(1)<<a<<endl;
    cout<<"the value of b is:"<<setw(2)<<b<<endl;
    cout<<"the value of c is:"<<setw(3)<<c<<endl;
    cout<<"the value of d is:"<<setw(4)<<d<<endl;
    cout<<"the value of e is:"<<setw(5)<<e<<endl;
    cout<<"the value of f is:"<<setw(1)<<f<<endl;
    cout<<"the value of g is:"<<setw(2)<<g<<endl;
    cout<<"the value of h is:"<<setw(3)<<h<<endl;
    cout<<"the value of i is:"<<setw(4)<<i<<endl;

    return 0;

}