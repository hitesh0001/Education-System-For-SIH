#include<iostream>

using namespace std;

int main(){

    //*********float , double and long double literals **********

    float d=55.4f;//F
    long double e=99.9l;//L
    cout<<"the size of 55.4 is"<<sizeof(55.4)<<endl;
    cout<<"the size of 55.4f is"<<sizeof(55.4f)<<endl;
    cout<<"the size of 55.4F is"<<sizeof(55.4F)<<endl;
    cout<<"the size of 55.4l is"<<sizeof(55.4l)<<endl;
    cout<<"the size of 55.4L is"<<sizeof(55.4L)<<endl;
    cout<<"the value of d is"<<d<<endl<<"the vale e is<<e";

    return 0 ;
    


}