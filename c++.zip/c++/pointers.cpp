#include<iostream>
using namespace std;

int main(){
    //what is a pointer? -----> data type which holds adress of other data types 

    int a =3;
    int*b =&a;
    // & --->(adress of )opertor
    cout<<"the adress of a is"<<&a<<endl;
    cout<<"the adress of a is"<<b<<endl;

    // *--->(value at)deferance operator
    cout<<"the value at adress b is "<<*b<<endl;
     
    return 0;
}