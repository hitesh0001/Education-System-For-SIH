//program to read age of candidate and determine whether he is eligible for vote or not
#include<iostream>
using namespace std;

int main(){
    int age ;
    cout<<"tell your age"<<endl;
    cin>>age;

    if (age<18){
        cout<<"you cannot vote"<<endl;
    }else{
        cout<<"you can vote"<<endl;
    }
    return 0;
}