//program to create array of objects of students
#include <iostream>
#include <string>

using namespace std;

class Student {
    string name;
    int age;
    float grade;
public:
    // Constructor
    Student(string n, int a, float g) : name(n), age(a), grade(g) {}
    
    // Method to display student information
    void display() {
        cout << "Name: " << name << ", Age: " << age << ", Grade: " << grade << endl;
    }
};

int main() {
    const int numStudents = 3; // Number of students
    Student students[numStudents] = {  // Array of Student objects
        Student("John", 20, 85.5),
        Student("Emma", 21, 90.0),
        Student("Alex", 19, 78.5)
    };
    
    // Display information of all students
    for (int i = 0; i < numStudents; ++i) {
        cout << "Student " << i + 1 << ":\n";
        students[i].display();
    }
    
    return 0;
}
