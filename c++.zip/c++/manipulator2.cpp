#include<iostream>
#include<iomanip>

using namespace std ;

int main(){
int a =4 ;

cout<<setw(2)<<a;
cout<<setw(2)<<a;
cout<<setw(2)<<a;
cout<<setw(2)<<a;
cout<<setw(2)<<a<<endl;
cout<<setw(2)<<a;
cout<<setw(8)<<a<<endl;
cout<<setw(2)<<a;
cout<<setw(2)<<a;
cout<<setw(2)<<a;
cout<<setw(2)<<a;
cout<<setw(2)<<a;


return 0;
}
