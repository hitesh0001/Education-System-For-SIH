//program to read and pront data of students using class and object
#include <iostream>
#include <string>
using namespace std;

// Define the Student class
class Student {
private:
    string name;
    int rollNumber;
    float marks;

public:
    // Function to read student data
    void readData() {
        cout << "Enter student's name: ";
        getline(cin, name);
        cout << "Enter roll number: ";
        cin >> rollNumber;
        cout << "Enter marks: ";
        cin >> marks;
    }

    // Function to print student data
    void printData() const {
        cout << "Student's Name: " << name << endl;
        cout << "Roll Number: " << rollNumber << endl;
        cout << "Marks: " << marks << endl;
    }
};

int main() {
    // Create an object of Student class
    Student student1;

    // Read data for the student
    student1.readData();

    // Print data of the student
    student1.printData();

    return 0;
}