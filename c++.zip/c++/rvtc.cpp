#include<iostream>

using namespace std;  

int c = 45 ;

int main() {

    //******referance variable******/

    float x = 449;
    float & y = x;
    cout<<x<<endl; 
    cout<<y<<endl;

   //******type casting********
   int a = 45;
   float b =45.46;
   cout<<"the vale of a "<<(float)a<<endl;
   cout<<"the vale of a "<<float(a)<<endl;
   
   cout<<"the vale of b "<<(float)b<<endl;
   cout<<"the vale of b "<<float(b)<<endl;
   int c = int(b); 

   cout<<"the expression is "<<a + b<<endl;
   cout<<"the expression is "<<a + int(b)<<endl;
   cout<<"the expression is "<<a + (int)b<<endl;
      
    return 0; 


} 