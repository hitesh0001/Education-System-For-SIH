#include<iostream>

using namespace std ;

int main(){
int age ;
cout<<"tell me your age "<<endl;
cin>>age;

if(age<18){
    cout<<"you can not smoke"<<endl;

}
else if(age==18){
    cout<<"you can smoke"<<endl;
}
else{
    cout<<"you dont need permission"<<endl;
}

return 0 ;

}

