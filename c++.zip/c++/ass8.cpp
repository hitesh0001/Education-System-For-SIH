//program to check whether an alphabet is vowel or not
#include<iostream>
using namespace std;

int main(){
    char ch ;

    cout<<"enter an alphabet";
    cin>>ch;

    if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u' ||
       ch == 'A' || ch == 'E' || ch == 'I' || ch == 'O' || ch == 'U'){
        cout<< ch <<" is a vowel"<<endl;
       } else {
        cout<<ch<<" is not a vowel"<<endl;
       }
    return 0;
}