//program to calculate total and percentage from 3 subjects
#include<iostream>
using namespace std;

int main(){
    float subject1 , subject2 , subject3 ;
    float total , percentage ;

    cout<<"enter the marks of subject1 ";
    cin>>subject1;

    cout<<"enter the marks of subject2 ";
    cin>>subject2;

    cout<<"enter the marks of subject3 ";
    cin>>subject3;

    total = subject1 + subject2 + subject3;
    percentage = (total/300)*100;

    cout<<"total marks "<<total <<endl;
    cout<<"percentage "<<percentage <<endl;

    return 0;
}