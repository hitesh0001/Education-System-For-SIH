#include<iostream>
using namespace std;

int main(){
    int i = 1 , n = 9 ;
    do{
        cout<<i*n<<endl;
        i++;
    }
    while(i<=10);
    
    return 0;
}