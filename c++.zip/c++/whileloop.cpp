#include<iostream>

using namespace std;
int main()
{
    /*syntax
    while(condition)
    {
        cpp statements;
    }
    */
  
  int i=1;
  while(i<=40){
    cout<<i<<endl;
    i++;
  }
  return 0 ;-/*/*/
}