#include<iostream>

using namespace std ;
int main()
{
/*syntax

do{
    cpp statements;
    }while(conditions);
    */

int i=1;
do{
    cout<<i<<endl;
    i++;
}while(i<=40);

return 0;

}