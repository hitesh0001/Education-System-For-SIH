//program to find the sum of 2,3 and 4 integer numbers using function overload
#include <iostream>
using namespace std;

// Function to find the sum of 2 integers
int sum(int a, int b) {
    return a + b;
}

// Function to find the sum of 3 integers
int sum(int a, int b, int c) {
    return a + b + c;
}

// Function to find the sum of 4 integers
int sum(int a, int b, int c, int d) {
    return a + b + c + d;
}

int main() {
    int num1, num2, num3, num4;

    cout << "Enter two integers: ";
    cin >> num1 >> num2;
    cout << "Sum of " << num1 << " and " << num2 << " = " << sum(num1, num2) << endl;

    cout << "Enter three integers: ";
    cin >> num1 >> num2 >> num3;
    cout << "Sum of " << num1 << ", " << num2 << ", and " << num3 << " = " << sum(num1, num2, num3) << endl;

    cout << "Enter four integers: ";
    cin >> num1 >> num2 >> num3 >> num4;
    cout << "Sum of " << num1 << ", " << num2 << ", " << num3 << ", and " << num4 << " = " << sum(num1, num2, num3, num4) << endl;

    return 0;
}
