#include<iostream>
using namespace std;

int main(){
    int age ;
    cout<<"type your age"<<endl;
    cin>>age;

    if(age==18){
        cout<<"leave home asap "<<endl;
    }
    else if(age<18){
        cout<<"think of ways to leave home"<<endl;

    }
    else{
        cout<<"stil stuck ... congrats your life is not yours ...get ready for barbadi ..as if its not happened yet"<<endl;
    }
    return 0;
}