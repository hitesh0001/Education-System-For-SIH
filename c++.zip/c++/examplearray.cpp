#include<iostream>
using namespace std;

int main(){
    //array example
    int marks [] = {23 , 55 , 77 , 78};
    cout<<"these are marks"<<endl; 
    cout<<marks[0]<<endl;
    cout<<marks[1]<<endl;
    cout<<marks[2]<<endl;
    cout<<marks[3]<<endl;
    
    int mathmarks[4];
    mathmarks[0] = 4455;
    mathmarks[1] = 445;
    mathmarks[2] = 455;
    mathmarks[3] = 45;

    cout<<"these are mathmarks"<<endl;
    cout<<mathmarks[0]<<endl;
    cout<<mathmarks[1]<<endl;
    cout<<mathmarks[2]<<endl;
    cout<<mathmarks[3]<<endl;

    return 0;
}