#include<iostream>

using namespace std ;

int main(){
    int a=4 , b=5;
    cout<<"operators in cpp:"<<endl;
    //arithematic operators
    cout<<"following are the types of arithematic operator in cpp:"<<endl;
    cout<<"the value of a + b is"<<a+b<<endl;
    cout<<"the value of a - b is"<<a-b<<endl;
    cout<<"the value of a * b is"<<a*b<<endl;
    cout<<"the value of a / b is"<<a/b<<endl; 
    cout<<"the value of a % b is"<<a%b<<endl; 
    cout<<"the value of a++ is"<<a++<<endl;
    cout<<"the value of a--  is"<<a--<<endl;
    cout<<"the value of ++a is"<<a--<<endl;
    cout<<"the value of --a is"<<a--<<endl;
    cout<<endl;
    

    //assignment operators ==>used to assign values to variables
    //int a=3, b=9;
   //char d = 'd';


   // comparison operators
   cout<<"following are the comparison operator in cpp:"<<endl;
   cout<<"the value of a == b is"<<(a==b)<<endl;
   cout<<"the value of a != b is"<<(a!=b)<<endl;
   cout<<"the value of a <= b is"<<(a<=b)<<endl;
   cout<<"the value of a >= b is"<<(a>=b)<<endl;
   cout<<"the value of a < b is"<<(a<b)<<endl;
   cout<<"the value of a > b is"<<(a>b)<<endl;


   //logical operations
   cout<<"following are the logical operator in cpp:"<<endl;
   cout<<"the value of this logical and operator((a==b) && (a<b))is:"<<((a==b) && (a<b))<<endl;
   cout<<"the value of this logical or operator((a==b) || (a<b))is:"<<((a==b) || (a<b))<<endl;
   cout<<"the value of this logical not operator(!(a==b)) is:"<<(!(a==b))<<endl;

   
   



    return 0;
}